﻿namespace API_Notizie
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbOpzioni = new System.Windows.Forms.ComboBox();
            this.txtCerca = new System.Windows.Forms.TextBox();
            this.btnCerca = new System.Windows.Forms.Button();
            this.immagine = new System.Windows.Forms.PictureBox();
            this.txtContenuto = new System.Windows.Forms.TextBox();
            this.txtDescrizione = new System.Windows.Forms.TextBox();
            this.txtTitolo = new System.Windows.Forms.TextBox();
            this.txtAutore = new System.Windows.Forms.TextBox();
            this.txtFonti = new System.Windows.Forms.TextBox();
            this.txtData = new System.Windows.Forms.TextBox();
            this.btnAvanti = new System.Windows.Forms.Button();
            this.btnIndietro = new System.Windows.Forms.Button();
            this.btnArticolo = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.immagine)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbOpzioni
            // 
            this.cmbOpzioni.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbOpzioni.FormattingEnabled = true;
            this.cmbOpzioni.Items.AddRange(new object[] {
            "Contenuto",
            "Sito web"});
            this.cmbOpzioni.Location = new System.Drawing.Point(12, 12);
            this.cmbOpzioni.Name = "cmbOpzioni";
            this.cmbOpzioni.Size = new System.Drawing.Size(152, 23);
            this.cmbOpzioni.TabIndex = 0;
            // 
            // txtCerca
            // 
            this.txtCerca.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCerca.Location = new System.Drawing.Point(170, 12);
            this.txtCerca.Name = "txtCerca";
            this.txtCerca.Size = new System.Drawing.Size(735, 23);
            this.txtCerca.TabIndex = 1;
            this.txtCerca.TextChanged += new System.EventHandler(this.txtCerca_TextChanged);
            // 
            // btnCerca
            // 
            this.btnCerca.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCerca.Enabled = false;
            this.btnCerca.Location = new System.Drawing.Point(911, 12);
            this.btnCerca.Name = "btnCerca";
            this.btnCerca.Size = new System.Drawing.Size(75, 23);
            this.btnCerca.TabIndex = 2;
            this.btnCerca.Text = "Cerca";
            this.btnCerca.UseVisualStyleBackColor = true;
            this.btnCerca.Click += new System.EventHandler(this.btnCerca_Click);
            // 
            // immagine
            // 
            this.immagine.Location = new System.Drawing.Point(781, 47);
            this.immagine.Name = "immagine";
            this.immagine.Size = new System.Drawing.Size(205, 131);
            this.immagine.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.immagine.TabIndex = 6;
            this.immagine.TabStop = false;
            this.immagine.Click += new System.EventHandler(this.btnArticolo_Click);
            // 
            // txtContenuto
            // 
            this.txtContenuto.Location = new System.Drawing.Point(12, 188);
            this.txtContenuto.Multiline = true;
            this.txtContenuto.Name = "txtContenuto";
            this.txtContenuto.ReadOnly = true;
            this.txtContenuto.Size = new System.Drawing.Size(974, 315);
            this.txtContenuto.TabIndex = 10;
            this.txtContenuto.Text = "Contenuto";
            // 
            // txtDescrizione
            // 
            this.txtDescrizione.Location = new System.Drawing.Point(12, 99);
            this.txtDescrizione.Multiline = true;
            this.txtDescrizione.Name = "txtDescrizione";
            this.txtDescrizione.ReadOnly = true;
            this.txtDescrizione.Size = new System.Drawing.Size(763, 79);
            this.txtDescrizione.TabIndex = 11;
            this.txtDescrizione.Text = "Descrizione";
            // 
            // txtTitolo
            // 
            this.txtTitolo.Location = new System.Drawing.Point(12, 73);
            this.txtTitolo.Multiline = true;
            this.txtTitolo.Name = "txtTitolo";
            this.txtTitolo.ReadOnly = true;
            this.txtTitolo.Size = new System.Drawing.Size(763, 23);
            this.txtTitolo.TabIndex = 12;
            this.txtTitolo.Text = "Titolo";
            // 
            // txtAutore
            // 
            this.txtAutore.Location = new System.Drawing.Point(12, 47);
            this.txtAutore.Multiline = true;
            this.txtAutore.Name = "txtAutore";
            this.txtAutore.ReadOnly = true;
            this.txtAutore.Size = new System.Drawing.Size(388, 23);
            this.txtAutore.TabIndex = 13;
            this.txtAutore.Text = "Autore";
            // 
            // txtFonti
            // 
            this.txtFonti.Location = new System.Drawing.Point(406, 47);
            this.txtFonti.Multiline = true;
            this.txtFonti.Name = "txtFonti";
            this.txtFonti.ReadOnly = true;
            this.txtFonti.Size = new System.Drawing.Size(263, 23);
            this.txtFonti.TabIndex = 14;
            this.txtFonti.Text = "Fonti";
            // 
            // txtData
            // 
            this.txtData.Location = new System.Drawing.Point(675, 47);
            this.txtData.Multiline = true;
            this.txtData.Name = "txtData";
            this.txtData.ReadOnly = true;
            this.txtData.Size = new System.Drawing.Size(100, 23);
            this.txtData.TabIndex = 15;
            this.txtData.Text = "01/01/2023";
            // 
            // btnAvanti
            // 
            this.btnAvanti.Enabled = false;
            this.btnAvanti.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnAvanti.Location = new System.Drawing.Point(911, 509);
            this.btnAvanti.Name = "btnAvanti";
            this.btnAvanti.Size = new System.Drawing.Size(75, 43);
            this.btnAvanti.TabIndex = 16;
            this.btnAvanti.Text = "»";
            this.btnAvanti.UseVisualStyleBackColor = true;
            this.btnAvanti.Click += new System.EventHandler(this.btnAvanti_Click);
            // 
            // btnIndietro
            // 
            this.btnIndietro.Enabled = false;
            this.btnIndietro.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnIndietro.Location = new System.Drawing.Point(12, 509);
            this.btnIndietro.Name = "btnIndietro";
            this.btnIndietro.Size = new System.Drawing.Size(75, 43);
            this.btnIndietro.TabIndex = 17;
            this.btnIndietro.Text = "«";
            this.btnIndietro.UseVisualStyleBackColor = true;
            this.btnIndietro.Click += new System.EventHandler(this.btnIndietro_Click);
            // 
            // btnArticolo
            // 
            this.btnArticolo.Enabled = false;
            this.btnArticolo.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnArticolo.Location = new System.Drawing.Point(352, 509);
            this.btnArticolo.Name = "btnArticolo";
            this.btnArticolo.Size = new System.Drawing.Size(317, 43);
            this.btnArticolo.TabIndex = 18;
            this.btnArticolo.Text = "Visita pagina articolo";
            this.btnArticolo.UseVisualStyleBackColor = true;
            this.btnArticolo.Click += new System.EventHandler(this.btnArticolo_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(998, 566);
            this.Controls.Add(this.btnArticolo);
            this.Controls.Add(this.btnIndietro);
            this.Controls.Add(this.btnAvanti);
            this.Controls.Add(this.immagine);
            this.Controls.Add(this.btnCerca);
            this.Controls.Add(this.txtCerca);
            this.Controls.Add(this.cmbOpzioni);
            this.Controls.Add(this.txtContenuto);
            this.Controls.Add(this.txtDescrizione);
            this.Controls.Add(this.txtTitolo);
            this.Controls.Add(this.txtAutore);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.txtFonti);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "API Notizie";
            ((System.ComponentModel.ISupportInitialize)(this.immagine)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ComboBox cmbOpzioni;
        private TextBox txtCerca;
        private Button btnCerca;
        private PictureBox immagine;
        private TextBox txtContenuto;
        private TextBox txtDescrizione;
        private TextBox txtTitolo;
        private TextBox txtAutore;
        private TextBox txtFonti;
        private TextBox txtData;
        private Button btnAvanti;
        private Button btnIndietro;
        private Button btnArticolo;
    }
}