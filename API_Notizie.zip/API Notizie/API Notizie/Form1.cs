using Newtonsoft.Json;
using System.Diagnostics;
using System.Net;

namespace API_Notizie
{
    public partial class Form1 : Form
    {
        // API key per accedere ai dati delle notizie
        string apiKey = "5ed45eff92b24a1c9880f23dff22e45b";

        // Variabili per tenere traccia dell'articolo corrente e del suo indice
        News currentNews = null;
        int currentIndex = 0;

        public Form1()
        {
            InitializeComponent();
            
            // Imposta la selezione predefinita della combobox a "Contenuto"
            cmbOpzioni.SelectedIndex = 0;
        }

        private void btnCerca_Click(object sender, EventArgs e)
        {
            // Resetta i campi di testo e disabilita i pulsanti di navigazione
            this.Text = "API Notizie";
            currentIndex = 0;
            currentNews = null;
            txtAutore.Text = "Autore";
            txtTitolo.Text = "Titolo";
            txtDescrizione.Text = "Descrizione";
            txtData.Text = "01/01/2023";
            txtFonti.Text = "Fonti";
            txtContenuto.Text = "Contenuto";
            btnAvanti.Enabled = false;
            btnIndietro.Enabled = false;
            btnArticolo.Enabled = false;

            // Costruisce l'url per la richiesta HTTP in base alla selezione della combobox
            string url = default;
            if (cmbOpzioni.Text == "Contenuto")
            {
                url = $"https://newsapi.org/v2/everything?q={txtCerca.Text}&apiKey={apiKey}&sortBy=popularity&language=it&searchIn=title,description";
            }
            else
            {
                url = $"https://newsapi.org/v2/everything?domains={txtCerca.Text}&apiKey={apiKey}&sortBy=popularity&language=it";
            }

            try
            {
                // Imposta il protocollo di sicurezza per la richiesta HTTP
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

                // Crea una richiesta HTTP GET con l'url costruito
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                request.Method = WebRequestMethods.Http.Get;
                request.ContentType = "application/json";

                // Imposta l'user agent della richiesta HTTP
                request.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:78.0) Gecko/20100101 Firefox/78.0";

                // Esegue la richiesta e ottiene la risposta HTTP
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();

                // Legge la risposta HTTP come stringa JSON e deserializza i dati in un oggetto News
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                string responseFromServer = reader.ReadToEnd();
                News news = JsonConvert.DeserializeObject<News>(responseFromServer);
                currentNews = news;

                // Se la richiesta ha avuto successo, abilita i pulsanti di navigazione
                if (news.totalResults == 0)
                {
                    MessageBox.Show("Nessun risultato trovato", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                
                // Mostra il primo articolo nella finestra dell'applicazione
                DisplayArticle(0);
            }
            catch (WebException ex)
            {
                // Gestisce eventuali errori nella richiesta HTTP
                var response = (HttpWebResponse)ex.Response;
                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
                MessageBox.Show(responseString, "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void DisplayArticle(int index)
        {
            // Imposta il titolo della finestra dell'applicazione con il numero e il totale degli articoli
            this.Text = $"API Notizie - Articolo {index + 1} su {currentNews.totalResults}";

            // Riempie i campi di testo con le informazioni dell'articolo corrente
            txtAutore.Text = currentNews.articles[index].author;
            txtTitolo.Text = currentNews.articles[index].title;
            txtDescrizione.Text = currentNews.articles[index].description;
            txtContenuto.Text = currentNews.articles[index].content;
            txtFonti.Text = currentNews.articles[index].source.name;
            txtData.Text = currentNews.articles[index].publishedAt.ToString("dd/MM/yyyy HH:mm");

            // Carica l'immagine dell'articolo corrente nell'PictureBox
            if (!string.IsNullOrEmpty(currentNews.articles[index].urlToImage) && !currentNews.articles[index].urlToImage.Contains("webp"))
            {
                immagine.Load(currentNews.articles[index].urlToImage);
            }
            else
            {
                immagine.Image = null;
            }



            // Abilita o disabilita i pulsanti di navigazione in base all'indice dell'articolo corrente
            if (index == 0)
            {
                btnIndietro.Enabled = false;
            }
            else
            {
                btnIndietro.Enabled = true;
            }

            if (index == currentNews.articles.Count - 1)
            {
                btnAvanti.Enabled = false;
            }
            else
            {
                btnAvanti.Enabled = true;
            }

            // Abilita il pulsante per aprire l'articolo nel browser
            btnArticolo.Enabled = true;
        }

        private void txtCerca_TextChanged(object sender, EventArgs e)
        {
            // Disabilita il pulsante di ricerca se il campo di testo � vuoto
            if (txtCerca.Text != "")
            {
                btnCerca.Enabled = true;
            }
            else
            {
                btnCerca.Enabled = false;
            }
        }

        private void btnArticolo_Click(object sender, EventArgs e)
        {
            // Apre l'articolo corrente nel browser
            Process.Start(new ProcessStartInfo(currentNews.articles[currentIndex].url) { UseShellExecute = true });
        }

        private void btnIndietro_Click(object sender, EventArgs e)
        {
            // Mostra l'articolo precedente
            currentIndex--;
            DisplayArticle(currentIndex);
        }

        private void btnAvanti_Click(object sender, EventArgs e)
        {
            // Mostra l'articolo successivo
            currentIndex++;
            DisplayArticle(currentIndex);
        }
    }

    // Classi che servono a contenere la risposta del server 
    public class News
    {
        public string status { get; set; }
        public int totalResults { get; set; }
        public List<Article> articles { get; set; }
    }
    
    public class Article
    {
        public Source source { get; set; }
        public string author { get; set; }
        public string title { get; set; }
        public string description { get; set; }
        public string url { get; set; }
        public string urlToImage { get; set; }
        public DateTime publishedAt { get; set; }
        public string content { get; set; }
    }

    public class Source
    {
        public string id { get; set; }
        public string name { get; set; }
    }
}